module.exports.config = {
	name: "baicahoatri",
	version: "1.0.0",
	hasPermssion: 0,
	credits: "LeMinh",
	description: "Bài ca hoá trị vip",
	commandCategory: "Kiến Thức Học Hỏi",
	cooldowns: 0
};

module.exports.run = ({ event, api }) => api.sendMessage(`Kali, Iot, Hiđro ,Natri với Bạc, Clo một loài

Có hóa trị I bạn ơi ,nhớ ghi cho rõ kẻo rồi phân vân

Magie, Chì, Kẽm, Thủy ngânCanxi, Đồng ấy cũng gần Bari

Cuối cùng thêm chú Oxi

Hóa trị II ấy có gì khó khăn

Bác Nhôm hóa trị III lần

Ghi sâu trí nhớ khi cần có ngay

Cacbon, Silic này đây

Là hóa trị IV không ngày nào quên

Sắt kia kể cũng quen tên

II, III lên xuống thật phiền lắm thay

Nitơ rắc rối nhất đời

I, II, III, IV khi thì là V

Lưu huỳnh lắm lúc chơi khăm

Lúc II, lúc VI khi nằm thứ IV

Photpho nói tới không dư

Nếu ai hỏi đến thì ừ rằng V

Bạn ơi cố gắng học chăm

Bài ca hóa trị suốt năm rất cần`, event.threadID, event.messageID);
